﻿var SiteAttention_initiate;
var SiteAttention_lastKeyword;

(function ($) {
    var initiated = false;

    SiteAttention_initiate = function () {
        var url = sa.globals.base_url + "/api/secure/license";

        if (!$('.SiteAttention_rule_long_description').text()) {
            return;
        }
        //console.log('SiteAttention_initiate');
        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: url,
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
            },
            tryCount: 0,
            retryLimit: 3,
            success: function (data) {
                sa.globals.expiry_date = new Date(data.expires);
                sa.globals.track_quota = data.track_quota;
                sa.globals.page_quota = data.page_quota;

                sa.globals.license_name = data.license_name;

                SiteAttention_getSASToken();
                SiteAttention_initiate_cb();
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    sa.globals.error_msg = 'SiteAttention: Error on calling endpoint' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(sa.globals.error_msg);
                    //SiteAttention();
                    sa.ui.init();
                    sa.ui.serverError.init();
                    sa.events.sendServerErrorEvent({ 'ServerError500': sa.globals.error_msg });

                } else if (xhr.status > 200 && xhr.status < 300) {
                    var response = JSON.parse(xhr.responseText);
                    sa.ui.expired.init();
                } else {
                    //handle error
                    var errMsg = new Error();
                    sa.globals.error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errMsg.stack;
                    console.error(sa.globals.error_msg);
                    //SiteAttention();
                    sa.ui.init();
                    var responseInit = JSON.parse(xhr.responseText);
                    sa.ui.serverError.init(sa.translate(responseInit.error.message));
                    sa.events.sendServerErrorEvent({ 'ServerError': sa.globals.error_msg });
                }
            }
        });


    };

    /*
    * Function to resize the tool w.r.t window size
    */
    function SiteAttention_resize_tool() {

        var sa_container = $('#SAPL', document);
        var body = $('body', document);
        var sa_container_height =
            $(window).height() -
            parseInt(body.css('paddingTop')) - parseInt(body.css('marginTop'));
        sa_container.height(sa_container_height);
    }

    /*
    * Initial function that gets called once the HTML is ready
    */
    function SiteAttention_initiate_cb() {

        //setTimeout(function () {
        SiteAttention_resize_tool(); // Resize tool to fit within window
        $('#SAPL input, #SAPL button', document).click(function (e) {  //Prevent 'edit form' submission on button clicks FROM the SiteAttention tool
            e.preventDefault();
            return false;
        });
        SiteAttention_getInitValues().then(function () {
            // Start SiteAttention UI //
            sa.initSelectors();
            sa.ui.init();
            //SiteAttention(); //COMMENT OUT when TESTING for UI
        });
    }

    document.addEventListener("SaWidgetReady", function (event) { // (1)
        /*
        * AFTER HTML is loaded START FUNCTION CALLS
        */
        //$('#SAPL', context).once(SiteAttention_initiate);

        if (!initiated) {
            SiteAttention_initiate();

            /*
            * Listen for window resize
            */
            window.onresize = function (event) {
                setTimeout(function () {
                    SiteAttention_resize_tool();
                }, 0);
            };

            //listen to changes from country picker
            if (document.getElementById('country-picker')) {
                document.getElementById('country-picker').addEventListener('change', function () {
                    sa.globals.content_country = document.getElementById('country-picker').value;

                    SiteAttention_getRulesScoresData(sa.keywordValue);
                });
            }
        }
    });

}(jQuery));