﻿var SiteAttention_DataHandler;
var SiteAttention_getRulesScoresData;
var SiteAttention_getReadability;
var SiteAttention_click_fields_listener;
var SiteAttention_getSemrushDomainList;
var SiteAttention_getSemrushResults;
var SiteAttention_getSemrushDomainDefault;
var SiteAttention_sas_token;
var SiteAttention_getInitValues;
var SiteAttention_getSASToken;
var rendered_html_replaced;
var rendered_html;
var SiteAttention_contentLang;
var SiteAttention_Automap;
var SiteAttention_ShowTooltip;

var SiteAttention_AttachedJS;
var SiteAttention_evalAttachedJS;
var SiteAttention_evalinlineJs;
var SiteAttention_kwsValue;
var SiteAttention_load = true;
var SiteAttention_count = 0;

(function ($, context) {

    SiteAttention_Automap = function () {
        $(".no-mapping .inline-loader").show();

        $.ajax({
            url: sa.globals.root_path + "/SiteAttentionToolbar/Automap",
            method: "POST",
            data: { pageId: sa.globals.pid },
            success: function (result) {
                $.ajax({
                    url: sa.globals.root_path + '/SiteAttentionToolbar/Index',
                    method: 'GET',
                    data: { pageReference: sa.globals.pid },
                    success: function (html) {
                        $(".no-mapping .inline-loader").hide();
                        $("#SAPL").html(html);

                    }
                });
            }
        });
    };

    /**Listen to click events on the seo field list on the tool **/

    SiteAttention_click_fields_listener = function () {
        $("img.focus_field").click(function () {
            var id = $(this).attr("data-sa-elem-id");
            var guid = id.split("::")[0];
            $(".SiteAttention_focus_field[data-sa-elem-id^=" + guid + "]").click();
        });

        $(".SiteAttention_focus_field").click(function () {
            var elementToFocus = $(this).attr("data-sa-elem-id");
            var propertyToFocus = elementToFocus.split("::")[1];

            if (propertyToFocus === "iroutable_routesegment") {
                $("[name='" + propertyToFocus + "']")[0].click();
            } else {
                siteAttentionModel.setActiveProperty(propertyToFocus);
            }
        });
    };


    SiteAttention_DataHandler = function () {
        SiteAttention_getRulesScoresData(sa.keywordValue);
    };

    /**
    *This function is to get the saved keyword and theshold score for the tool before load
    * @returns {Function} result of ajax
    */
    SiteAttention_getInitValues = function () {
        var iid = sa.globals.iid;
        var pid = sa.globals.pid;
        var cms = sa.globals.cms;
        var username = sa.globals.username;
        var content_lang = sa.globals.content_lang;
        if (SiteAttention_contentLang) {
            content_lang = SiteAttention_contentLang;
        }
        var url = sa.globals.base_url + '/api/secure/init/' + iid + '/' + pid + '/' + cms + '/' + content_lang;
        return new Promise(function (resolve) {
            $.ajax({
                headers: {
                    Accept: "application/json; charset=utf-8",
                    "Content-Type": "application/json; charset=utf-8"
                },
                url: url,
                data: {},
                //crossDomain: true,
                dataType: "xml/html/script/json", // expected format for response
                contentType: "application/json", // send as JSON
                type: "GET",
                tryCount: 0,
                retryLimit: 3,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
                },
                success: function (data) {

                    var res = JSON.parse(data);
                    SiteAttention_lastKeyword = res.data_keywords;
                    SiteAttention_threshold_score = res.data_score_threshold;

                    resolve(data);
                },
                error: function (xhr, textStatus, errorThrown) {
                    if (textStatus === 'timeout') {
                        this.tryCount++;
                        if (this.tryCount <= this.retryLimit) {
                            $.ajax(this);//try again
                            return;
                        }
                        return;
                    }
                    if (xhr.status === 500) {
                        //handle error
                        var err = new Error();
                        error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                        console.error(error_msg);
                        sa.ui.serverError.init(error_msg);
                        sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });

                    } else {
                        //handle error
                        var errGeneric = new Error();
                        error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                        console.error(error_msg);
                        sa.ui.serverError.init(error_msg);
                        sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                    }
                }
            });
        });
    };

    /**
     * Get the dynamic response of each rule like status description, rule score, page score , readability 
     * @param {Function} callback callback function
     **/
    function getHtml(callback) {
        //function updateToolbar(previewHtml) {
        $.ajax({
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ previewUrl: sa.globals.previewUrl }),
            url: sa.globals.root_path + "/SiteAttentionToolbar/SiteattentionHtml?language=" + sa.globals.content_lang,
            success: function (html) {
                //console.log(html);
                callback(html);
            }
        });
    }

    SiteAttention_ShowTooltip = function (item) {
        var tipsClass = item.classList;
        tipsClass.toggle('SA_popup_show');
        setTimeout(function () {
            tipsClass.remove('SA_popup_show');
        }, 15000);
    };

    SiteAttention_getRulesScoresData = function (data_keywords) {
        getHtml(function (html) {
            if (html === "")
                return;

            var rules_refresh_url = sa.globals.rules_refresh_url;
            var domain = sa.globals.client_domain;
            var cms = sa.globals.cms;
            var username = sa.globals.username;
            var pid = sa.globals.pid;
            var published = sa.globals.published;
            var content_lang = sa.globals.content_lang;
            if (SiteAttention_contentLang) {
                content_lang = SiteAttention_contentLang;
            }
            var data_dompage = sa.globals.page_url;
            if (document.getElementById('country-picker').value !== "-") {
                if (sa.globals.content_country !== document.getElementById('country-picker').value) {
                    sa.globals.content_country = document.getElementById('country-picker').value;
                }
            }
            var content_country = sa.globals.content_country;
            var basedomain;

            if (SiteAttention_contentLang) {
                content_lang = SiteAttention_contentLang;
            }

            var mappings = [];
            $(html).each(function () {
                if ($(this).attr("id") !== null && $(this).attr("id") !== "") {
                    mappings.push({
                        selectorId: $(this).attr("id"),
                        selectorClassNames: "",
                        scope: $(this).attr("data-sa-scope"),
                        delta: "",
                        fieldName: $(this).attr("data-sa-label"),
                        fieldLabel: $(this).attr("data-sa-label")
                    });
                }


            });

            ////Check if the container with the kws value exist, if it does assign the value to kwsValue
            if (document.getElementById('siteattention-kws-average')) {
                SiteAttention_kwsValue = document.getElementById('siteattention-kws-average').innerHTML;
                if (isNaN(SiteAttention_kwsValue) || SiteAttention_kwsValue === 0) {
                    SiteAttention_kwsValue = 400;
                }
            }
            if (SiteAttention_kwsValue === undefined) {
                SiteAttention_kwsValue = 400;
            }

            var data = JSON.stringify({
                kwsvalue: SiteAttention_kwsValue,
                country: content_country,
                content_lang: content_lang,
                data_txt: html,
                data_keywords: data_keywords,
                seo_selector_elems: mappings,
                protocol: location.protocol,
                domain: domain,
                pid: pid,
                cms: cms,
                username: username,
                published: published,
                dompage: data_dompage
            });
            $.ajax({
                headers: {
                    Accept: "application/json; charset=utf-8",
                    "Content-Type": "application/json; charset=utf-8"
                },
                url: rules_refresh_url + "/" + pid,
                data: data,
                //crossDomain: true,
                dataType: "xml/html/script/json", // expected format for response
                contentType: "application/json", // send as JSON
                type: "POST",
                tryCount: 0,
                retryLimit: 3,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
                },
                success: function (data) {
                    //console.log(data);
                    let res = JSON.parse(data);
                    let score = res.score_pct;
                    let readability = res.readability;
                    if (res.kwsvalue) {
                        SiteAttention_kwsValue = res.kwsvalue.value;
                    }

                    sa.ui.main.update_bar_percentage(score);
                    SiteAttention_update_rule_status(res);

                    ////Make an array that will contain the attached js givin from the backend
                    SiteAttention_AttachedJS = [];
                    res.attached_js.forEach(function (el, index) {
                        SiteAttention_AttachedJS.push(el);
                    });

                    ////set the value of the average word count in the long description
                    if (document.getElementById('siteattention-kws-average')) {
                        document.getElementById('siteattention-kws-average').innerHTML = SiteAttention_kwsValue;
                    }

                    //Change key word search select to match the response from DB
                    $('#SiteAttention_keyword_difficulty_region optgroup option[value="us"]').attr('selected', 'selected');
                    $('#SiteAttention_keyword_difficulty_region optgroup option').each(function() {
                        if (this.value.toUpperCase() === res.country) {
                            $(this).attr('selected', 'selected');
                           
                        }
                    });

                    //Set the basedomain to the result givin from the backend
                    basedomain = res.inline_js[0]['basedomain'];

                    //Change country picker select to match the response from DB
                    $('#country-picker option').each(function () {
                        if (this.value === res.country) {
                            $(this).attr('selected', 'selected');
                        }
                        content_country = res.country;
                        sa.globals.content_country = content_country;
                    });

                    //Send all the data into the SiteAttention_evalAttachedJS, that will evaluad the attached js and insert the needed data to it
                    SiteAttention_evalAttachedJS(SiteAttention_AttachedJS, data_keywords.split(',')[0], content_lang, content_country, basedomain);

                    //Workaround for double load
                    if (SiteAttention_count > 1) {
                        //This is used to prevend the kws to fire at page load
                        SiteAttention_load = false;
                    }
                  
                    sa.score = score;
                    sa.readability = readability;
                    SiteAttention_getReadability(); // update readability score

                    $('#sa-page-score-val').html(score);

                    // listens to the clicks on SiteAttention tool's 'SEO field names'
                    SiteAttention_click_fields_listener();

                },
                error: function (xhr, textStatus, errorThrown) {
                    if (textStatus === 'timeout') {
                        this.tryCount++;
                        if (this.tryCount <= this.retryLimit) {
                            $.ajax(this);//try again
                            return;
                        }
                        return;
                    }
                    if (xhr.status === 500) {
                        //handle error
                        var err = new Error();
                        error_msg = 'SiteAttention: Error on calling endpoint ' + rules_refresh_url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                        console.error(error_msg);
                        //SiteAttention(context);
                        sa.ui.serverError.init(error_msg);
                        sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });

                    } else {
                        //handle error
                        var errGeneric = new Error();
                        error_msg = 'SiteAttention: Error on calling endpoint ' + rules_refresh_url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                        console.error(error_msg);
                        //SiteAttention(context);
                        sa.ui.serverError.init(error_msg);
                        sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                    }
                }
            });
        });
    };

    /**Get the readability interval for easy, good and advanced **/

    SiteAttention_getReadability = function () {
        var content_lang = sa.globals.content_lang;
        if (SiteAttention_contentLang) {
            content_lang = SiteAttention_contentLang;
        }
        var rules_readability_url = sa.globals.rules_readability_url + content_lang;
        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: rules_readability_url,
            data: {},
            //crossDomain: true,
            dataType: "xml/html/script/json", // expected format for response
            contentType: "application/json", // send as JSON
            type: "GET",
            tryCount: 0,
            retryLimit: 3,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
            },
            success: function (data) {
                let res = JSON.parse(data);
                sa.ui.main.update_readability_bar_percentage(sa.readability, res);
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + rules_readability_url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(error_msg);
                    //SiteAttention(context);
                    sa.ui.serverError.init(error_msg);
                    sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });

                } else {
                    //handle error
                    var errGeneric = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + rules_readability_url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                    console.error(error_msg);
                    //SiteAttention(context);
                    sa.ui.serverError.init(error_msg);
                    sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                }
            }
        });
    };

    /**This function is to update the status of every rule in the HTML */

    SiteAttention_update_rule_status = function (array) {

        Object.keys(array).map(function (item) {
            if (item === 'rule_categories') {
                var cat = array[item];
                Object.keys(cat).map(function (i) {
                    let cat_id = cat[i]['id'];
                    let cat_pct = cat[i]['score_pct'];
                    let pie_id = "SiteAttention_rules_cat_" + cat_id + "_pie";
                    sa.ui.main.update_rule_scope_pie(pie_id, cat_pct);
                    let rules = cat[i]['rules'];
                    Object.keys(rules).map(function (rule) {
                        let rule_id = rules[rule]['id'];
                        let rule_pct = rules[rule]['score_pct'];
                        let status_desc = rules[rule]['status_description'];
                        let long_desc = rules[rule]['long_description'];
                        sa.ui.main.update_rule_pie(rule_id, rule_pct);
                        sa.ui.main.update_rule_status_description(rule_id, status_desc, long_desc);
                    });
                });
            }
        });

    };

    /*
    *This function that evaluate the javascript send from the backend
    */
    SiteAttention_evalAttachedJS = function (arr, keyword, language, country, basedomain) {
        eval(arr[0]['keywordscraper']);
        //Ensure that the kws do not get triggered at load
        if (!SiteAttention_load && (document.getElementById("kws-container") !== null && document.getElementById("kws-container").className !== "kws-hidden")) {
            scrapingBegin();
        }
        SiteAttention_count++;
    };

    /*
    *This function is to get the dropdown list of domains in the keyword search
    */

    SiteAttention_getSemrushDomainList = function (type) {
        var url = sa.globals.base_url + "/api/sr/databasesbykey";

        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: url,
            data: JSON.stringify({ type: type }),
            //crossDomain: true,
            dataType: "xml/html/script/json", // expected format for response
            contentType: "application/json", // send as JSON
            type: "POST",
            tryCount: 0,
            retryLimit: 3,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
            },
            success: function (data) {
                //console.log(data);
                let res = JSON.parse(data);
                if (type === 'prim') {
                    sa.ui.phrase.populateList(res, 'prim');
                }
                if (type === 'sec') {
                    sa.ui.phrase.populateList(res, 'sec');
                }

            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(error_msg);
                    sa.ui.serverError.notifyError(sa.translate('SiteAttention: Error on calling endpoint ') + url);
                    sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });
                } else {
                    //handle error
                    var errGeneric = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                    console.error(error_msg);
                    sa.ui.serverError.notifyError(sa.translate('SiteAttention: Error on calling endpoint ') + url);
                    sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                }
            }
        });
    };

    /*
    *This function is to get the default selection of regions in the keyword search options
    */
    SiteAttention_getSemrushDomainDefault = function () {
        var url = sa.globals.semrush_url;
        var cmslang = sa.globals.content_lang;
        if (SiteAttention_contentLang) {
            cmslang = SiteAttention_contentLang;
        }
        var domainname = sa.globals.page_url;

        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: url,
            data: JSON.stringify({ domainname: domainname, cmslang: cmslang }),
            //crossDomain: true,
            dataType: "xml/html/script/json", // expected format for response
            contentType: "application/json", // send as JSON
            type: "POST",
            tryCount: 0,
            retryLimit: 3,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
            },
            success: function (data) {
                var domain = Object.keys(JSON.parse(data));
                sa.ui.phrase.defaultRegion = domain[0];
                SiteAttention_getSemrushDomainList('prim');
                SiteAttention_getSemrushDomainList('sec');
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(error_msg);
                    sa.ui.phrase.defaultRegion = 'us';
                    SiteAttention_getSemrushDomainList('prim');
                    SiteAttention_getSemrushDomainList('sec');
                    sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });
                } else {
                    //handle error
                    var errGeneric = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                    console.error(error_msg);
                    sa.ui.phrase.defaultRegion = 'us';
                    SiteAttention_getSemrushDomainList('prim');
                    SiteAttention_getSemrushDomainList('sec');
                    sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                }
            }
        });
    };

    /*
    *This function is to get the results of Keyword Search
    */

    SiteAttention_getSemrushResults = function (type, phrase, region) {
        var url = sa.globals.base_url + "/api/sr/" + type;
        var domain = sa.globals.page_url;
        var license = sa.globals.xsa;
        var user = sa.globals.username;
        var pid = sa.globals.pid;
        var contentLanguage = sa.globals.content_lang;
        if (SiteAttention_contentLang) {
            contentLanguage = SiteAttention_contentLang;
        }
        var uiLanguage = sa.globals.ui_lang;

        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: url,
            data: JSON.stringify({ phrase: phrase, region: region, domain: domain, license: license, username: user, contentLanguage: contentLanguage }),
            //crossDomain: true,
            dataType: "xml/html/script/json", // expected format for response
            contentType: "application/json", // send as JSON
            type: "POST",
            tryCount: 0,
            retryLimit: 3,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
            },
            success: function (data) {
                let res = JSON.parse(data);
                sa.ui.phrase.handle_response(res);
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(error_msg);
                    sa.ui.phrase.handle_error();
                    sa.events.sendServerErrorEvent({ 'ServerError500': error_msg });
                } else {
                    //handle error
                    var errGeneric = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                    console.error(error_msg);
                    sa.ui.phrase.handle_error();
                    sa.events.sendServerErrorEvent({ 'ServerError': error_msg });
                }
            }
        });

        sa.events.sendSemrushCallEvent({ SemrushCall: { type: type, phrase: phrase, region: region } });
    };

    /*
    *This function is to get the shared access token for the sas eventhub
    */

    SiteAttention_getSASToken = function () {
        var url = sa.globals.base_url + "/api/sas/token";
        $.ajax({
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: url,
            data: {},
            //crossDomain: true,
            dataType: "xml/html/script/json",
            contentType: "application/json",
            type: "GET",
            tryCount: 0,
            retryLimit: 3,
            //async:true,
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-SiteAttention', sa.globals.xsa);
                xhr.setRequestHeader('Allow-Control-Allow-Origin', '*');
            },
            success: function (data) {
                var dataParsed = JSON.parse(data);
                SiteAttention_sas_token = dataParsed.token;
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                    return;
                }
                if (xhr.status === 500) {
                    //handle error
                    var err = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + err.stack;
                    console.error(error_msg);
                } else {
                    //handle error
                    var errGeneric = new Error();
                    error_msg = 'SiteAttention: Error on calling endpoint ' + url + ', error status:' + xhr.status + '\n' + 'Error response: ' + xhr.responseText + '\n' + errGeneric.stack;
                    console.error(error_msg);
                }
            }
        });
    };

}(jQuery, document));
