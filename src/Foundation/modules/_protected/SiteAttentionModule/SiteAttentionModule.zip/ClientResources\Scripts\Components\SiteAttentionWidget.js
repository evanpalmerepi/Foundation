﻿define([
    //"dojo",
    "dojo/_base/declare",
    "dojo/_base/lang",
    //"dojo/_base/xhr",
    //"dojo/html",
    "dojo/aspect",
    //"dojo/on",
    "dojo/topic",
    //"dojo/when",

    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",

    //"epi/dependency",
    //"epi/username",
    "epi/shell/XhrWrapper"
    //"epi/shell/_ContextMixin"
    //"epi-cms/ApplicationSettings",
    //"epi-cms/_ContentContextMixin"

],

function (
    //dojo,
    declare,
    lang,
    //xhr,
    //html,
    aspect,
    //on,
    topic,
    //when,

    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,

    //dependency,
    //username,
    XhrWrapper,
    //_ContextMixin
    //appSettings,
    //_ContentContextMixin
) {

    // summary: Integration of SiteAttention in EPiServer.
    return declare("siteattention/Components/SiteAttentionWidget", [_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        templateString: '<div id="siteattention_area">\
                        <div data-dojo-attach-point="contentName2" id="SAPL">\
                        </div>\
                    </div>',

        _xhrWrapper: new XhrWrapper(),

        _unwatchHandle: null,

        _innerUnwatchHandle: null,

        modelChangeSubscribed: false,
        
        postCreate: function () {
            if (!this.modelChangeSubscribed) {
                topic.subscribe("siteattention/modelchanged", lang.hitch(this, "_onModelChanged"));
                this.modelChangeSubscribed = true;
            }
        },

        startup: function () {
            //subscribe to context changed to get trash event
            this.subscribe("/epi/shell/context/changed", this._contextChanged);

            require(["dijit/registry"], function (registry) {
                var componentContainers = document.getElementsByClassName("epi-componentContainer");
                for (var i = 0; i < componentContainers.length; i++) {
                    var widget = registry.byId(componentContainers[i].getAttribute("widgetid"));
                    aspect.around(widget, "addComponent", function (originalMethod) {
                        return function (component) {
                            if (typeof SiteAttention !== 'undefined') {
                                if (component.moduleName === "SiteAttentionModule") {
                                    alert('SiteAttention has already been added.');
                                    return [];
                                }
                            }
                            return originalMethod.apply(this, arguments);
                        };
                    });
                }
            });
        },

        _contextChanged: function (ctx) {
            if (!ctx) {
                return;
            }
            if (ctx.customViewType === "epi-cms/component/Trash") {
                //console.log(ctx.customViewType);
                var path = ctx.previewUrl.split("/");
                var resolved_url = '/' + path[1] + '/SiteAttentionModule/SiteAttentionToolbar/Index';
                $.ajax({
                    url: resolved_url,
                    method: 'GET',
                    data: { pageReference: ctx.id },
                    success: function (html) {
                        $("#SAPL").html(html);
                    },
                    error: function (response) {
                        //console.error(response.statusText);
                    }
                });
            }

        },

        postMixInProperties: function () {
        },

        _onModelChanged: function (model) {
            //console.log('rendering toolbar', model.contentData.contentLink);
            window.siteAttentionModel = model;
            var path = model.contentData.previewUrl.split("/");
            var resolved_url = '/' + path[1] + '/SiteAttentionModule/SiteAttentionToolbar/Index';
            $.ajax({
                url: resolved_url,
                method: 'GET',
                data: { pageReference: model.contentData.contentLink },
                success: function (html) {
                    $("#SAPL").html(html);
                },
                error: function (response) {
                    //console.error(response.statusText);
                }
            });
        }
    });
});
