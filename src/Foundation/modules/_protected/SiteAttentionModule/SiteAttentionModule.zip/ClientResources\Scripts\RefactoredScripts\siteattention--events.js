﻿sa.events = function () {

    function sendEventToRecordApi(data) {
        //console.log('sending record event', data.meta.eventId, data);
        $.ajax({
            url: sa.globals.root_path +  "/SiteAttentionToolbar/SendNotification",
            data: { json: JSON.stringify(data) },
            type: "POST",
            tryCount: 0,
            retryLimit: 3,
            success: function (response) {
                //console.log('record event send ', data.meta.eventId, response);
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                }
            }
        });
    }

    function sendEventToHub(data) {
        var url = "https://sa-event-hub.servicebus.windows.net/logstash/messages";
        //console.log('sending hub event', data.eventId, data);
        $.ajax({
            headers: {
                Accept: "application/atom+xml;type=entry;charset=utf-8 "
            },
            url: url,
            data: JSON.stringify(data),
            dataType: "xml/html/script/json/jsonp", // expected format for response
            contentType: "application/json", // send as JSON
            type: "POST",
            host: "sa-event-hub.servicebus.windows.net",
            tryCount: 0,
            retryLimit: 3,
            async: true,
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
                xhr.setRequestHeader("Authorization", SiteAttention_sas_token);
            },
            success: function (response) {
                //console.log('hub event send ', data.eventId, response);
            },
            error: function (xhr, textStatus, errorThrown) {
                if (textStatus === 'timeout') {
                    this.tryCount++;
                    if (this.tryCount <= this.retryLimit) {
                        $.ajax(this);//try again
                        return;
                    }
                }
            }
        });
    }

    function getRecordEventData(eventId, event, type) {
        return {
            siteattentionlog: "log",
            meta: {
                eventId: eventId,
                event: event,
                type: type,
                browser: window.navigator.userAgent,
                key: sa.globals.xsa,
                instance: sa.globals.instanceId,
                domain: sa.globals.client_domain,
                cms: "Episerver"
            }
        }
    }

    function getHubEventData(eventId) {
        return {
            eventId: eventId,
            domain: sa.globals.client_domain,
            license: sa.globals.xsa,
            instanceId: sa.globals.iid,
            userName: sa.globals.username,
            pid: sa.globals.pid,
            contentLanguage: SiteAttention_contentLang || sa.globals.content_lang,
            uiLanguage: sa.globals.ui_lang
        }
    }

    function sendSemrushCallEvent(eventData) {
        var hubData = getHubEventData(504);
        hubData["events"] = eventData;
        sendEventToHub(hubData);
    }

    function sendClickCounterEvent(eventData) {
        var hubData = getHubEventData(502);
        hubData["events"] = eventData;
        sendEventToHub(hubData);
    }

    function sendKeywordEntryEvent(eventData) {
        var hubData = getHubEventData(502);
        hubData["events"] = eventData;
        sendEventToHub(hubData);

        var recordData = getRecordEventData(106, "changed", "phrase");
        recordData["data"] = eventData;
        sendEventToRecordApi(recordData);
    }

    function sendLoadedEvent(eventData) {
        var recordData = getRecordEventData(105, "loaded", "plugin");
        recordData["data"] = eventData;
        sendEventToRecordApi(recordData);
    }

    function sendServerErrorEvent(errorLog) {
        var hubData = getHubEventData(501);
        hubData["error"] = errorLog;
        sendEventToHub(hubData);

        var recordData = getRecordEventData(501, "error", "servererror");
        recordData["data"] = errorLog;
        sendEventToRecordApi(recordData);
    }

    return {
        sendSemrushCallEvent: sendSemrushCallEvent,
        sendClickCounterEvent: sendClickCounterEvent,
        sendKeywordEntryEvent: sendKeywordEntryEvent,
        sendLoadedEvent: sendLoadedEvent,
        sendServerErrorEvent: sendServerErrorEvent
    };

}();