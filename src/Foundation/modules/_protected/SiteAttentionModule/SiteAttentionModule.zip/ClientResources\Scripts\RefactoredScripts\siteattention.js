﻿var siteAttention = {}, sa = siteAttention;

sa.globals = {
    expiry_date: new Date(),
    license_name: "",
    iid: 78,
    xsa: null,
    error_msg: "",
    cms: "",
    pid: 0,
    content_lang: "en",
    ui_lang: "en",
    base_url: "",
    rules_refresh_url: 'https://rest.siteattention.com/api/secure/rules',
    rules_readability_url: 'https://rest.siteattention.com/api/text/readability/',
    semrush_url: 'https://rest.siteattention.com/api/sr/domainselect',
    client_domain: "localhost",
    page_url: "http://localhost:56124/",
    fieldLabels: "",
    username: "",
    published: true,
    root_path: "",
    previewUrl: "",
    data_tokens: {},
    mappings: {}
};

sa.translate = function (str) {
    //TODO translate str
    return str;
};

sa.initSelectors = function () {
    sa.score = 0;
    sa.readability = 0;
    sa.pushNotification = document.getElementById("SiteAttention_notification");
    sa.slideOut = document.getElementById('SiteAttention_slide_logo');

    sa.homeView = document.getElementById('SiteAttention_home');
    sa.mainView = document.getElementById('SiteAttention_main');
    sa.expiredView = document.getElementById('SiteAttention_expired');
    sa.upgradeView = document.getElementById('SiteAttention_upgrade');

    sa.homeKeywordInput = document.getElementById('SiteAttention_home_keyword_input');
    sa.homeKeywordButton = document.getElementById('SiteAttention_keyword_button');
    sa.keywordHelpLink = document.getElementById('SiteAttention_keyword_help_link');
    sa.keywordHelpText = document.getElementById('SiteAttention_keyword_help_text');
    sa.keywordHelpClose = document.getElementById('SiteAttention_keyword_help_text_close');

    sa.addKeywordButton = document.getElementById('SiteAttention_add_search_phrase');
    sa.keywordTagsBox = document.getElementById('SiteAttention_search_phrase_tags');
    sa.messageNotification = document.getElementById('SiteAttention_message_notification');
    sa.messageText = document.getElementById('SiteAttention_message_text');
    sa.messageClose = document.getElementById('SiteAttention_message_close');
    sa.keywordEmptyWarning = document.getElementById('SiteAttention_keyword_empty_warning');

    sa.frameScoreText = document.getElementById('SiteAttention_score_text');
    sa.frameContent = document.getElementById('SiteAttention_content');

    sa.scoreBarPercentage = document.getElementById('SiteAttention_score_bar_percentage');
    sa.scoreBarBackground = document.getElementById('SiteAttention_score_bar_background');
    sa.score_value = document.getElementById('SiteAttention_score_value');
    sa.score_threshold = document.getElementById('SiteAttention_threshold_arrow');
    sa.score_threshold_text = document.getElementById('SiteAttention_threshold_text');
    sa.readabilityBarPercentage = document.getElementById('SiteAttention_readability_bar_percentage');
    sa.readabilityBarBackground = document.getElementById('SiteAttention_readability_bar_background');

    sa.readabilityBarBackgroundSpan1 = document.getElementById('SiteAttention_readability_bar_background_span1');
    sa.readabilityBarBackgroundSpan2 = document.getElementById('SiteAttention_readability_bar_background_span2');
    sa.readabilityBarBackgroundSpan3 = document.getElementById('SiteAttention_readability_bar_background_span3');

    sa.readabilityBarPercentageSpan1 = document.getElementById('SiteAttention_readability_bar_percentage_span1');
    sa.readabilityBarPercentageSpan2 = document.getElementById('SiteAttention_readability_bar_percentage_span2');
    sa.readabilityBarPercentageSpan3 = document.getElementById('SiteAttention_readability_bar_percentage_span3');

    sa.readabilityBarScaleMark1 = document.getElementById('SiteAttention_readability_bar_scaleMark1');
    sa.readabilityBarScaleMark2 = document.getElementById('SiteAttention_readability_bar_scaleMark2');
    sa.readabilityBarScaleMark3 = document.getElementById('SiteAttention_readability_bar_scaleMark3');
    sa.readability_element = document.getElementById('SiteAttention_readability_score');

    sa.accordions = document.getElementsByClassName('SiteAttention_accordion');
    sa.rules_container = document.getElementById('SiteAttention_rules_container');
    sa.rules = document.getElementById('SiteAttention_rules');
    sa.search_phrase_element = document.getElementById('SiteAttention_search_phrase');
    sa.search_phrase_container = document.getElementById('SiteAttention_search_phrase_input');
    sa.help_tooltips = document.getElementsByClassName('SA_popup');
    sa.restart_btn = document.getElementById('SiteAttention_restart');
};