﻿var siteattention_seo_selector_elems = [];


sa.ui = {
    state: 'max', //default state of tool is maximised ( Slide out)

    init: function () {
        sa.messageClose.onclick = sa.ui.apiMessage.hideMessage;

        sa.ui.apiMessage.checkMessage();

        var today = new Date();
        if (sa.globals.error_msg) {
            sa.ui.serverError.init(sa.globals.error_msg);// If error , display error message
            return;
        }
        //if (sa.globals.xsa && sa.globals.xsa.length > 0) { //If already existing customer*
        if (sa.globals.expiry_date) {//If license is valid, then load the tool
            if (today < sa.globals.expiry_date) {
                if (sa.globals.track_quota < sa.globals.page_quota) {//If the page quota is valid
                    if (SiteAttention_lastKeyword && SiteAttention_lastKeyword.length > 0) {//if keyword saved then switchToMain else remain in Home View
                        sa.ui.main.init();
                        sa.ui.switchToMain();
                        sa.ui.main.insertKeywordToMainView(SiteAttention_lastKeyword);
                    }
                    else {
                        sa.ui.switchToHome();
                        if (sa.globals.meta_keywords !== null && sa.globals.meta_keywords.length > 0) {
                            sa.ui.main.init();
                            sa.ui.switchToMain();
                            for (var i = 0; i < sa.globals.meta_keywords.length; i++) {
                                sa.ui.main.insertKeywordToMainView(sa.globals.meta_keywords[i]);
                            }

                        }
                    }
                    sa.ui.main.clickHomeKeywordButton();//click listener for Enter Keyword Button in Home
                    sa.ui.togglekeywordHelpModal();//click listener for Keyword Help Link on home view
                }
                else {
                    console.warn('SiteAttention: Page Quota is over. Upgrade the tool! ');
                    sa.ui.upgrade.init();
                }
            }
        }
        //}
        //else {
        //    sa.ui.onboard.init();// If new customer, then show the onboard view
        //}
    },

    apiMessage: {
        //listen to api messages

        getMessage: function () {
            var message = true; //Dummy response
            if (message) {
                sa.ui.apiMessage.checkMessage();
            }
        },

        //if there is message, and expiry date is not past, then get message (get message id, name ,message text, expiry date);
        //if no cookie, display the message in the tool , set cookie as 'shown', set expiry date
        checkMessage: function () {
            //dummy data
            var message_id = 1;
            var message_name = 'SA_message:welcome';
            var message_text = sa.translate('Welcome to SiteAttention v5.0.0.') + ' ' + '<br\/><a id="SA_message_link" href="https://landing.siteattention.com/siteattention-learning-center" target="_blank" title="SiteAttention learning centre">' + sa.translate("Learn how to use SiteAttention") + '<\/a>';
            var exDate = new Date();
            exDate.setDate(exDate.getDate() + 360);
            var expiry_date = exDate;

            var isShown = sa.util.cookie.get(message_name);
            if (!isShown) {
                var today = new Date();
                if (today < expiry_date) {
                    var timeDiff = expiry_date - today;
                    var exp_days = Math.ceil(timeDiff / (1000 * 3600 * 24));
                    sa.ui.apiMessage.showMessage(message_text);
                    //setTimeout(sa.ui.apiMessage.hideMessage, 8000);
                    sa.util.cookie.set(message_name, 'shown', exp_days);
                }
            }

        },

        showMessage: function (text) {
            sa.messageNotification.classList.add('SA_snackbar_show');
            if (sa.homeView) {
                sa.homeView.classList.add('SA_blur');
            }
            if (sa.mainView) {
                sa.mainView.classList.add('SA_blur');
            }

            sa.messageText.innerHTML = text;
        },

        hideMessage: function () {
            sa.messageNotification.classList.remove("SA_snackbar_show");
            if (sa.homeView) {
                sa.homeView.classList.remove('SA_blur');
            }
            if (sa.mainView) {
                sa.mainView.classList.remove('SA_blur');
            }

        }

    },

    /*
    * Function to track the user click behaviors
    */
    clickCounter: {

        saveClickCount: function (el_name) {
            var date = new Date();
            var time = date.getTime();
            sa.events.sendClickCounterEvent({ 'Element': el_name, 'timestamp': time });
        }
    },

    /*
    * Switch to the Main view with seo rules
    */
    switchToMain: function () {
        document.getElementById("SiteAttention_notification").style.display = 'none';
        document.getElementById('SiteAttention_home').style.display = 'none'; // set display to none to other views as well
        document.getElementById('SiteAttention_main').style.display = 'block';
        document.getElementById('SiteAttention_expired').style.display = 'none';
        document.getElementById('SiteAttention_server_error').style.display = 'none';
        document.getElementById('SiteAttention_upgrade').style.display = 'none';
        document.getElementById('SiteAttention_onboard_outer').style.display = 'none';

    },

    /*
    * Switch to the blue Home View
    */
    switchToHome: function () {
        if (document.getElementById('SiteAttention_home') === null)
            return;
        document.getElementById('SiteAttention_home').style.display = 'table'; //display - use 'table', dont use 'block'
        document.getElementById('SiteAttention_main').style.display = 'none';
        document.getElementById("SiteAttention_notification").style.display = 'block';
        document.getElementById('SA_notification_text').innerText = sa.translate("Keyword not entered");
        document.getElementById('SiteAttention_expired').style.display = 'none';
        document.getElementById('SiteAttention_upgrade').style.display = 'none';
        document.getElementById('SiteAttention_onboard_outer').style.display = 'none';
        document.getElementById('SiteAttention_server_error').style.display = 'none';
    },

    /*
    * Click listener for Need Help with Keyword Link on the blue Home View
    */
    togglekeywordHelpModal: function () {
        if (sa.keywordHelpLink == null)
            return;

        sa.keywordHelpLink.onclick = function () {
            sa.keywordHelpText.classList.toggle('SA_modal_show');
        };
        sa.keywordHelpClose.onclick = function () {
            sa.keywordHelpText.classList.remove('SA_modal_show');
        };
    },

    /*
    * Function to call the data handler that updates the keyword value in the backend
    */
    saveKeywordValue: function () {
        sa.keywordValue = document.getElementById('SiteAttention_search_phrase').value;
        SiteAttention_DataHandler();
    },

    /**************
    * MAIN VIEW *
    ***************/
    main: {
        init: function () {
            /**Click listener to create Keyword Button**/
            sa.ui.main.createKeywordInputBox();

            /**click listener for showing help info**/
            sa.ui.main.showHelpText();

            //Keyword Search
            sa.ui.phrase.init();

            sa.search_phrase_element.placeholder = sa.translate('Fill at least one keyword');
            /*Restore the scroll position from the last session on load*/
            sa.ui.main.checkScrollPosition();

            //rules
            sa.ui.main.checkAccordion();
            sa.ui.main.toggleAccordion();

            /*save tools scroll position*/
            sa.ui.main.saveScrollPosition();

            // listens to the clicks on SiteAttention tool's 'SEO field names'
            SiteAttention_click_fields_listener();
            SiteAttention_getSemrushDomainDefault();

            sa.messageClose.onclick = sa.ui.apiMessage.hideMessage;
        },

        /*
        * Function to create an input box and add listeners when the plus/add Button is clicked
        */
        createKeywordInputBox: function () {

            var inputBox = document.createElement('INPUT');
            inputBox.setAttribute('type', 'text');
            inputBox.className = "SA_add_keyword_input";

            //click listener on add button
            sa.addKeywordButton.onclick = function (event) {
                sa.ui.clickCounter.saveClickCount(sa.addKeywordButton.getAttribute("data-sa-click"));
                sa.addKeywordButton.style.display = 'none';
                sa.keywordTagsBox.insertBefore(inputBox, sa.ui.main.addKeywordButton);
                inputBox.value = ""; //start with empty box
                inputBox.focus(); //focus input on start
                //Listener on keyup event
                inputBox.onkeyup = function (event) {

                    var x = event.which || event.keyCode;
                    var keyword = inputBox.value;

                    if (keyword.slice(-1) === '|' || keyword.slice(-1) === ',') {
                        keyword = keyword.slice(0, -1);
                    }

                    var isKeywordRepeat = sa.ui.main.isKeywordRepeated(keyword);

                    //when user presses enter key, use the input box value to create tag
                    if (x == 13) {
                        inputBox.onblur = "";
                        //check for null value and white space
                        if (keyword != '' && !/^\s*$/.test(keyword)) {
                            //if keyword is unique then create tag and remove the input box
                            if (!isKeywordRepeat) {
                                sa.ui.main.createKeywordTag(keyword);
                                sa.util.removeElement(inputBox);
                                sa.addKeywordButton.style.display = 'block';
                            } else {
                                inputBox.classList.add('SiteAttention_blink');
                            }
                        }
                    } else {
                        //if the keyword is repeated then warn the user with blink
                        if (!isKeywordRepeat) {
                            inputBox.classList.remove('SiteAttention_blink');
                        } else {
                            inputBox.classList.add('SiteAttention_blink');
                        }

                    }
                }

                //remove the input box when the user clicks outside of box
                inputBox.onblur = function () {
                    if (inputBox && document.getElementById('SiteAttention_search_phrase').value !== '') {
                        sa.util.removeElement(inputBox);
                        sa.addKeywordButton.style.display = 'block';
                    }
                }

            }
        },

        /*
        * Function to create tags with keyword
        */
        createKeywordTag: function (keyword, sendEvent = true) {

            var tagBox = document.createElement('DIV');
            tagBox.className = "SA_keyword_tag";
            var tagText = document.createElement('SPAN');
            tagBox.appendChild(tagText);
            var tagDelete = document.createElement('DIV');
            tagDelete.className = 'SA_keyword_tag_delete';
            tagDelete.innerText = 'X';
            tagBox.appendChild(tagDelete);
            sa.ui.main.clickTagDelete(tagBox, tagDelete, tagText);

            tagText.innerText = keyword;

            sa.keywordTagsBox.insertBefore(tagBox, sa.addKeywordButton);
            //add the keyword to the hidden input field
            sa.ui.main.addkeywordToMainInput(keyword);
            if (sendEvent)
                sa.events.sendKeywordEntryEvent({ 'KeywordEntry': keyword });

        },

        /*
        * Function to listen to delete 'x' on each keyword tag
        */
        clickTagDelete: function (tag, cross, text) {
            cross.onclick = function () {
                var index = sa.util.getChildNodeIndex(tag);
                sa.ui.main.removekeywordFromMainInput(index);
                sa.ui.phrase.removeKDSelection(text);
                sa.util.removeElement(tag);
                sa.ui.main.showKeywordWarning();
            }
        },

        /*
        * Function to check if the keyword entered by user is repeated
        */
        isKeywordRepeated: function (keyword) {
            var phrase = document.getElementById('SiteAttention_search_phrase').value.split(',');
            for (var i = 0; i < phrase.length; i++) {
                if (phrase[i].toUpperCase() == keyword.toUpperCase()) {
                    return true;
                }
            }
            return false;
        },

        /*
        * Function to add keyword to the hidden input field, while a tag is added
        */
        addkeywordToMainInput: function (val) {
            var isKeywordRepeat = sa.ui.main.isKeywordRepeated(val);
            if (!isKeywordRepeat) {
                if (document.getElementById('SiteAttention_search_phrase').value != '') {
                    val = ',' + val;
                }
                document.getElementById('SiteAttention_search_phrase').value += val;
                // save phrase
                sa.ui.saveKeywordValue();
            }
            sa.ui.main.showKeywordWarning();
        },

        /*
        * Function to remove keyword to the hidden input field, while a tag is removed
        */
        removekeywordFromMainInput: function (position) {

            var phrase = document.getElementById('SiteAttention_search_phrase').value.split(',');
            for (var i = 0; i < phrase.length; i++) {
                if (i == position) {
                    phrase.splice(i, 1); //remove that element
                    document.getElementById('SiteAttention_search_phrase').value = phrase;
                    //save phrase
                    sa.ui.saveKeywordValue();
                    return;
                }
            }
        },

        /*
        * Function to show help texts when the help icons are clicked
        */
        showHelpText: function () {
            var tips = sa.help_tooltips;
            var i;
            for (i = 0; i < tips.length; i++) {
                tips[i].onclick = function () {
                    var tipsClass = this.nextElementSibling.children[0].classList;
                    tipsClass.toggle('SA_popup_show');
                    setTimeout(function () {
                        tipsClass.remove('SA_popup_show');
                    }, 15000);
                };
            }
        },

        /*
        * Click listener for the home view's next button
        */
        clickHomeKeywordButton: function () {
            if (sa.homeKeywordButton) {
                sa.homeKeywordButton.onclick = sa.ui.main.enterKeyword;
                //for iE browsers
                if (!sa.homeKeywordButton.onclick) {
                    sa.homeKeywordButton.attachEvent('click', sa.ui.main.enterKeyword);
                }

                sa.homeKeywordInput.onkeyup = function (event) {
                    if (event.keyCode == 13) {
                        sa.ui.main.enterKeyword();
                    }
                }
            }
        },

        /*
        * Validate keyword entered and insert into the Main View Tag
        */
        enterKeyword: function (event) {
            sa.ui.clickCounter.saveClickCount(sa.homeKeywordButton.getAttribute("data-sa-click"));
            var keyword = sa.homeKeywordInput.value;
            if (keyword != '' || !/^\s*$/.test(keyword)) {
                if (keyword.slice(-1) == ',' || keyword.slice(-1) == '|') {
                    keyword = keyword.slice(0, -1);
                }
                sa.ui.main.init();
                sa.ui.switchToMain();
                sa.ui.main.insertKeywordToMainView(keyword);
            }
        },

        /*
        * Insert keyword entered from Home page into hidden field, create tag
        */
        insertKeywordToMainView: function (val) {
            var phrase = val.split(',');
            for (var i = 0; i < phrase.length; i++) {

                var isKeywordRepeat = sa.ui.main.isKeywordRepeated(phrase[i]);

                if (!isKeywordRepeat) {
                    if (document.getElementById('SiteAttention_search_phrase').value.length > 0) {
                        document.getElementById('SiteAttention_search_phrase').value += ',' + phrase[i];
                    } else {
                        document.getElementById('SiteAttention_search_phrase').value += phrase[i];
                    }

                    sa.ui.main.createKeywordTag(phrase[i], false);
                }
            }
            sa.ui.saveKeywordValue();
        },

        /*
        * Function to check if the keyword list is empty, if empty then show warnings
        */
        showKeywordWarning: function () {
            if (document.getElementById('SiteAttention_search_phrase')) {
                if (document.getElementById('SiteAttention_search_phrase').value != '') {
                    var tooltipClass = document.getElementById('SiteAttention_keyword_empty_warning').nextElementSibling.children[0].classList;
                    tooltipClass.remove('SA_popup_show');
                    sa.keywordEmptyWarning.style.display = 'none';
                } else if (document.getElementById('SiteAttention_search_phrase').value == '') {
                    sa.addKeywordButton.click();
                    document.getElementById('SiteAttention_keyword_empty_warning').click();
                    sa.keywordEmptyWarning.style.display = 'block';
                }
            }
        },

        clickKDButton: function () {
            sa.ui.phrase.KDButton.addEventListener('click', sa.ui.phrase.toggleKDPanel);
            sa.ui.phrase.close.addEventListener('click', sa.ui.phrase.hideKDPanel);
        },

        toggleKDPanel: function (event) {
            sa.ui.clickCounter.saveClickCount(sa.ui.phrase.KDButton.getAttribute("data-sa-click"));
            if (sa.ui.phrase.KDPanel.style.display == 'block') {
                sa.ui.phrase.hideKDPanel();
            } else {
                sa.rules_container.style.display = 'none'
                sa.ui.phrase.KDPanel.style.display = 'block';
                sa.ui.phrase.KDButton.classList.add('SA_btn_active');
                sa.ui.phrase.phrase.value = document.getElementById('SiteAttention_search_phrase').value;
                sa.ui.phrase.phrase.value = sa.ui.phrase.phrase.value.split(',')[0]; //show only the first keyword to search
                sa.ui.phrase.phrase.focus();
            }
        },

        hideKDPanel: function () {
            sa.rules_container.style.display = 'block'
            sa.ui.phrase.KDPanel.style.display = 'none';
            sa.ui.phrase.KDButton.classList.remove('SA_btn_active');
            sa.ui.phrase.clear_search();
        },

        /*
        * Click listener for the Rules category accordion
        */
        toggleAccordion: function () {

            var acc = sa.accordions;
            var i;
            for (i = 0; i < acc.length; i++) {
                acc[i].addEventListener("click", function (event) {

                    sa.ui.clickCounter.saveClickCount(this.getAttribute("data-sa-click"));

                    sa.ui.main.showKeywordWarning();

                    var accName = this.id;
                    this.classList.toggle("SA_active");
                    var panel = this.nextElementSibling;
                    if (panel.style.maxHeight) {
                        sa.util.cookie.set(accName, 'closed', 10);
                        panel.style.maxHeight = null;
                    } else {
                        sa.util.cookie.set(accName, 'open', 10);
                        panel.style.maxHeight = '100%';
                    }

                });
            }
        },

        /*
        * Check cookies on load to see if the accordions are closed or open in the previous session
        */
        checkAccordion: function () {
            var acc = sa.accordions;
            var i;

            for (i = 0; i < acc.length; i++) {
                var accName = acc[i].id;
                var accStatus = sa.util.cookie.get(accName);
                if (accStatus == 'open') {
                    acc[i].classList.add("SA_active");
                    acc[i].nextElementSibling.style.maxHeight = '100%';
                }
            }
        },

        /*save the last scroll position of the tool**/
        saveScrollPosition: function () {
            sa.frameContent.addEventListener('scroll', function (event) {
                event.preventDefault();
                var scrollTop = sa.frameContent.scrollTop;
                sa.util.cookie.set('SiteAttention:ScrollPos', scrollTop, 10);
            })
        },

        /**check the last scroll position of the tool and set it as the scroll position on load*/
        checkScrollPosition: function () {
            var pos = Number(sa.util.cookie.get('SiteAttention:ScrollPos'));
            if (sa.frameContent) {
                if (!sa.util.detectIEorEdge) {
                    sa.frameContent.scrollTo(0, pos);
                } else {
                    sa.frameContent.scrollTop = pos;
                }
            }
        },

        /*
        * Update SiteAttention score progress bar on tool
        */
        update_bar_percentage: function (score) {
            var frameScoreTextPaddingRight = 100 - score + 5; //extra padding 5
            var threshold = 80;
            if (SiteAttention_threshold_score) {
                threshold = SiteAttention_threshold_score;
            }

            sa.scoreBarPercentage.style.width = `${score}%`;
            sa.score_value.textContent = `${score}%`;
            sa.frameScoreText.style.paddingRight = frameScoreTextPaddingRight < 82 ? `${frameScoreTextPaddingRight}%` : `82%`;
            sa.score_threshold.style.marginLeft = `${threshold - 2}%`;
            sa.score_threshold_text.textContent = +threshold + "%";
            sa.score_threshold.title = "Required Target: " + threshold + "%";
            sa.scoreBarBackground.style.backgroundColor = `#E5E5E5`;


            if (score > threshold || score == threshold) {
                sa.scoreBarPercentage.style.backgroundColor = `#4DB0E9`;
                sa.frameScoreText.children[0].style.color = `#4DB0E9`;
            }
            else {
                sa.scoreBarPercentage.style.backgroundColor = `rgba(195,0 ,47, 0.8)`;
                sa.frameScoreText.children[0].style.color = `rgba(195,0 ,47, 1)`;
            }
        },

        /*
        * Update SiteAttention readability progress bar on tool
        */
        update_readability_bar_percentage: function (readability, array) {
            var easy_min = array[0].interval_min;
            var easy_max = array[0].interval_max; var easy_text = array[0].interval_descr;
            var good_min = array[1].interval_min;
            var good_max = array[1].interval_max; var good_text = array[1].interval_descr;
            var advanced_min = array[2].interval_min;
            var advanced_max = array[2].interval_max; var advanced_text = array[2].interval_descr;

            var percentage = 0;

            if (readability < advanced_max) {
                percentage = readability / advanced_max * 100;
            } else {
                percentage = 100;
            }

            var span1width = (easy_max - easy_min) / advanced_max * 100;
            var span2width = (good_max - easy_max) / advanced_max * 100;
            var span3width = (advanced_max - good_max) / advanced_max * 100;

            sa.readabilityBarBackgroundSpan1.style.width = `${span1width}%`;
            sa.readabilityBarBackgroundSpan2.style.width = `${span2width}%`;
            sa.readabilityBarBackgroundSpan3.style.width = `${span3width}%`;

            sa.readabilityBarScaleMark1.style.width = `${span1width}%`;
            sa.readabilityBarScaleMark2.style.width = `${span2width}%`;
            sa.readabilityBarScaleMark3.style.width = `${span3width}%`;

            sa.readabilityBarPercentage.style.width = `${percentage}%`;

            if (readability < easy_max) {
                sa.readability_element.textContent = easy_text;
                sa.readabilityBarPercentage.style.backgroundColor = `rgba(65, 221, 137, 0.6)`;
                sa.readability_element.style.color = `rgba(65, 221, 137, 1)`;
                sa.readability_element.style.marginLeft = "10px";
                sa.readabilityBarPercentageSpan1.style.width = `0%`;
                sa.readabilityBarPercentageSpan2.style.width = `0%`;
                sa.readabilityBarPercentageSpan3.style.width = '0%';
                sa.readabilityBarPercentageSpan1.style.backgroundColor = `transparent`;
                sa.readabilityBarPercentageSpan2.style.backgroundColor = `transparent`;
                sa.readabilityBarPercentageSpan3.style.backgroundColor = `transparent`;
            }

            else if (readability > easy_max && readability <= good_max) {
                sa.readability_element.textContent = good_text;
                var diff = percentage - span1width;
                sa.readabilityBarPercentageSpan1.style.width = `${span1width}%`;
                sa.readabilityBarPercentageSpan2.style.width = `${diff}%`;
                sa.readabilityBarPercentageSpan3.style.width = '0%';
                sa.readabilityBarPercentage.style.backgroundColor = 'transparent';
                sa.readabilityBarPercentageSpan1.style.backgroundColor = `rgba(65, 221, 137, 0.6)`;//green
                sa.readabilityBarPercentageSpan2.style.backgroundColor = `rgba(246, 143, 70, 0.6)`; //orange
                sa.readabilityBarPercentageSpan3.style.backgroundColor = `transparent`;
                sa.readability_element.style.color = `rgba(246, 143, 70, 1)`;
                if (advanced_max < 15) {
                    sa.readability_element.style.marginLeft = "110px";
                } else {
                    sa.readability_element.style.marginLeft = "125px";
                }
            }

            else if (readability > good_max) {
                sa.readability_element.textContent = advanced_text;
                var diff = percentage - (span1width + span2width);
                sa.readabilityBarPercentageSpan1.style.width = `${span1width}%`;
                sa.readabilityBarPercentageSpan2.style.width = `${span2width}%`;
                sa.readabilityBarPercentageSpan3.style.width = `${diff}%`;
                sa.readabilityBarPercentage.style.backgroundColor = 'transparent';
                sa.readabilityBarPercentageSpan1.style.backgroundColor = `rgba(65, 221, 137, 0.6)`;
                sa.readabilityBarPercentageSpan2.style.backgroundColor = `rgba(246, 143, 70, 0.6)`;
                sa.readabilityBarPercentageSpan3.style.backgroundColor = `rgba(195,0 ,47, 0.6)`;//red
                sa.readability_element.style.color = `rgba(195, 0, 47, 1)`;
                sa.readability_element.style.marginLeft = "220px";
            }

        },

        /*
        * Update rule category pie chart percentage
        */
        update_rule_scope_pie: function (pie_element_id, percentage) {
            var pie_element = document.getElementById(pie_element_id);
            pie_element.textContent = Math.round(percentage) + '%';
            var pie = pie_element;
            var p = parseFloat(pie.textContent);
            var NS = "http://www.w3.org/2000/svg";
            var svg = document.createElementNS(NS, "svg");
            var circle = document.createElementNS(NS, "circle");
            var title = document.createElementNS(NS, "title");
            circle.setAttribute("r", 16);
            circle.setAttribute("cx", 16);
            circle.setAttribute("cy", 16);
            circle.setAttribute("stroke-dasharray", p + " 100");
            svg.setAttribute("viewBox", "0 0 32 32");
            title.textContent = pie.textContent;
            pie.textContent = '';
            svg.appendChild(title);
            svg.appendChild(circle);
            pie.appendChild(svg);
        },

        /*
        * Calculate & display the status for each rule , tick , cross or pie status
        */
        update_rule_pie: function (id, percentage) {

            var el_id = '#SiteAttention_rule_' + id,
                pie_check = ' .SiteAttention_piechart_check',
                pie_cross = ' .SiteAttention_piechart_cross',
                pie_el = ' .SiteAttention_piechart'

            var piechart_check = document.getElementsByClassName(el_id + pie_check);
            var piechart_cross = document.getElementsByClassName(el_id + pie_cross);
            var pie = document.querySelector(el_id + pie_el);

            if (percentage == 0) {
                sa.util.bala('.SiteAttention_piechart', piechart_cross);
                document.querySelector(el_id + ' .SiteAttention_piechart').style.display = 'none';
                document.querySelector(el_id + ' .SiteAttention_piechart_cross').style.display = 'inline-flex';
                document.querySelector(el_id + ' .SiteAttention_piechart_check').style.display = 'none';
            }
            else if (percentage == 100) {
                sa.util.bala('.SiteAttention_piechart', piechart_check);
                document.querySelector(el_id + ' .SiteAttention_piechart').style.display = 'none';
                document.querySelector(el_id + ' .SiteAttention_piechart_cross').style.display = 'none';
                document.querySelector(el_id + ' .SiteAttention_piechart_check').style.display = 'inline-flex';
            }
            else {
                document.querySelector(el_id + ' .SiteAttention_piechart').style.display = 'inline-flex';
                document.querySelector(el_id + ' .SiteAttention_piechart_cross').style.display = 'none';
                document.querySelector(el_id + ' .SiteAttention_piechart_check').style.display = 'none';
                var circle = document.querySelector(el_id + ' .SiteAttention_rule_percentage');
                var svgPercentage = 339.292 * (1 - percentage / 100);
                if (circle) {
                    circle.style.strokeDashoffset = `${svgPercentage}`;
                }
            }
        },

        update_rule_status_description: function (id, status_desc, long_desc) {

            var rule_el_id = '#SiteAttention_rule_' + id;
            var status_el_id = ' .SiteAttention_rule_variable_text';
            var long_el_id = ' .SiteAttention_rule_long_description';

            var status_el = document.querySelector(rule_el_id + status_el_id);
            var long_el = document.querySelector(rule_el_id + long_el_id);
            status_el.innerHTML = status_desc;
            long_el.innerHTML = long_desc;
        }

    },

    /***********************
    * KEYWORD SEARCH VIEW **
    ************************/
    phrase: {
        /*
        * Initiate the Keyword Search panel
        **/
        init: function () {
            sa.ui.phrase.KDButton = document.getElementById('SiteAttention_keyword_difficulty_btn');
            sa.ui.phrase.KDPanel = document.getElementById('SiteAttention_keyword_difficulty');
            sa.ui.phrase.close = document.getElementById('SiteAttention_KD_title_close');
            sa.ui.phrase.search = document.getElementById('SiteAttention_keyword_difficulty_search');
            sa.ui.phrase.result = document.getElementById('SiteAttention_keytool_results');
            sa.ui.phrase.error = document.getElementById('SiteAttention_keytool_error');
            sa.ui.phrase.phrase = document.getElementById('SiteAttention_keyword_difficulty_phrase')
            sa.ui.phrase.searchLoading = document.getElementById('SiteAttention_keyword_difficulty_search_loading');
            sa.ui.phrase.searchError = document.getElementById('SiteAttention_keyword_difficulty_search_error');
            sa.ui.phrase.region = document.getElementById('SiteAttention_keyword_difficulty_region');
            sa.ui.phrase.KDHelpTips = document.getElementById('SiteAttention_kd_help_tips');
            sa.ui.phrase.KDSearchExact = document.getElementById('SiteAttention_keyword_difficulty_exact');
            sa.ui.phrase.KDSearchRelated = document.getElementById('SiteAttention_keyword_difficulty_related');
            sa.ui.phrase.KDSearchExact.addEventListener('click', sa.ui.phrase.exact);
            sa.ui.phrase.KDSearchRelated.addEventListener('click', sa.ui.phrase.related);
            sa.ui.phrase.exact(); //default selection;

            //Open KDI panel on KDButton click, hide SEO rules
            sa.ui.phrase.clickKDButton();

            //On keyword search
            sa.ui.phrase.phrase.addEventListener('keyup', function (event) {
                if (event.keyCode === 13) {
                    sa.ui.clickCounter.saveClickCount(sa.ui.phrase.phrase.getAttribute("data-sa-click"));
                    sa.ui.phrase.clear_search();
                    if (sa.ui.phrase.phrase.value && !/^\s*$/.test(sa.ui.phrase.phrase.value)) // also checking if the searched value is whitespace
                    {
                        sa.ui.phrase.searchPhrase(); // Call Backend
                        sa.ui.phrase.searchError.innerHTML = '';
                    }
                    else {
                        sa.ui.phrase.searchError.innerHTML = sa.translate("Empty Search! try again!");
                        sa.ui.phrase.searchLoading.style.display = 'none';
                    }
                }
            });

            sa.ui.phrase.search.addEventListener('click', function (event) {
                sa.ui.clickCounter.saveClickCount(sa.ui.phrase.search.getAttribute("data-sa-click"));
                sa.ui.phrase.clear_search();
                if (sa.ui.phrase.phrase.value && !/^\s*$/.test(sa.ui.phrase.phrase.value)) {
                    sa.ui.phrase.searchError.innerHTML = '';
                    sa.ui.phrase.searchPhrase(); // Call Backend
                }
                else {
                    sa.ui.phrase.searchError.innerHTML = sa.translate("Empty Search! try again!");
                    sa.ui.phrase.searchLoading.style.display = `none`;
                }

            });
        },

        /*
        * Listen to Keyword Search button and Close button
        **/
        clickKDButton: function () {
            sa.ui.phrase.KDButton.addEventListener('click', sa.ui.phrase.toggleKDPanel);
            sa.ui.phrase.close.addEventListener('click', sa.ui.phrase.hideKDPanel);
        },

        /*
        * Function to show Keyword Search Panel
        **/
        toggleKDPanel: function (event) {
            sa.ui.clickCounter.saveClickCount(sa.ui.phrase.KDButton.getAttribute("data-sa-click"));
            if (sa.ui.phrase.KDPanel.style.display == 'block') {
                sa.ui.phrase.hideKDPanel();
            } else {
                sa.rules_container.style.display = 'none'
                sa.ui.phrase.KDPanel.style.display = 'block';
                sa.ui.phrase.KDButton.classList.add('SA_btn_active');
                sa.ui.phrase.phrase.value = document.getElementById('SiteAttention_search_phrase').value;
                sa.ui.phrase.phrase.value = sa.ui.phrase.phrase.value.split(',')[0]; //show only the first keyword to search
                sa.ui.phrase.searchError.innerHTML = '';
                sa.ui.phrase.phrase.focus();
            }
        },
        /*
        * Function to populate list of domains inside optgroup dropdown
        **/
        populateList: function (res, key) {
            var html = "";
            Object.keys(res).map(function (item) {
                if (item == sa.ui.phrase.defaultRegion) {
                    html = html + "<option value=" + item + " selected >" + res[item] + "</option>";
                } else {
                    html = html + "<option value=" + item + " >" + res[item] + "</option>";
                }
            });
            if (html.length > 0) {
                document.getElementById('SiteAttention_regions_list_' + key).innerHTML = html;
            }

        },

        /**Action on exact button click **/
        exact: function () {
            sa.ui.phrase.KDSearchType = 'exact';
            sa.ui.phrase.KDSearchExact.classList.add('SA_KD_active');
            sa.ui.phrase.KDSearchRelated.classList.remove('SA_KD_active');
        },

        /**Action on related button click **/
        related: function () {
            sa.ui.phrase.KDSearchType = 'related';
            sa.ui.phrase.KDSearchExact.classList.remove('SA_KD_active');
            sa.ui.phrase.KDSearchRelated.classList.add('SA_KD_active');
        },

        /*
        * Function to search Keyword in Keyword Search
        **/
        searchPhrase: function () {
            sa.ui.phrase.error.textContent = '';

            if (sa.ui.phrase.search) {
                sa.ui.phrase.search.style.display = "none";
                sa.ui.phrase.searchLoading.style.display = "inline-flex";
            }

            /*var  type = document.getElementById('SiteAttention_keyword_tool_related').checked
            ? 'related'
            : 'exact';*/ // Incase of radio buttons

            var type = sa.ui.phrase.KDSearchType;

            var phrase = sa.ui.phrase.phrase.value;
            var el = document.getElementById("SiteAttention_keyword_difficulty_region");
            var region = el.options[el.selectedIndex].value;

            if (phrase.length < 2) {
                return;
            }

            SiteAttention_getSemrushResults(type, phrase, region);

        },

        handle_response: function (response) {
            if (sa.ui.phrase.search) {
                sa.ui.phrase.search.style.display = "inline-flex";
                sa.ui.phrase.searchLoading.style.display = "none";
            }

            if (response && response.length === 0) {
                sa.ui.phrase.searchError.innerHTML = sa.translate('No results were found');
            }

            sa.ui.phrase.clean();
            sa.ui.phrase.populateResults(response);
            sa.ui.phrase.bind_use_button();
        },

        handle_error: function () {
            sa.ui.phrase.search.style.display = "inline-flex";
            sa.ui.phrase.searchLoading.style.display = "none";
            var message = sa.translate('Something went wrong ! Try again.');
            sa.ui.phrase.searchError.textContent = message;
        },
        /*
        * Function to hide Keyword Search Panel
        **/
        hideKDPanel: function () {
            sa.rules_container.style.display = 'block';
            sa.ui.phrase.KDPanel.style.display = 'none';
            sa.ui.phrase.KDButton.classList.remove('SA_btn_active');
            sa.ui.phrase.clear_search();
        },

        /*
        * Function to listen to 'use' button on keyword search results
        **/
        bind_use_button: function () {
            for (var el of document.querySelectorAll('.SiteAttention_keyword_difficulty_use_it')) {
                el.addEventListener('click', function (event) {
                    sa.ui.clickCounter.saveClickCount(el.getAttribute("data-sa-click"));
                    event.target.classList.add('SA_btn_active');
                    event.target.innerText = sa.translate('Selected');
                    var word = event.target.parentElement.getElementsByClassName('SiteAttention_keyword_difficulty_result_word')[0],
                        val = word.textContent;

                    var isKeywordRepeat = sa.ui.main.isKeywordRepeated(val);

                    if (!isKeywordRepeat) {
                        sa.ui.main.createKeywordTag(val);
                    }

                });
            }

        },

        /*
        * Unselect the 'use' button
        **/
        removeKDSelection: function (text) {
            for (var el of document.querySelectorAll('.SiteAttention_keyword_difficulty_use_it')) {

                var word = el.parentElement.getElementsByClassName('SiteAttention_keyword_difficulty_result_word')[0];
                var val = word.textContent;
                if (val == text.innerText) {
                    el.classList.remove('SA_btn_active');
                    el.innerText = sa.translate('Select');
                }

            }
        },

        /*
        * Function to populate the Keyword search results
        **/
        populateResults: function (results) {
            sa.ui.phrase.result.style.display = 'inline-block';
            //sa.ui.phrase.clear_result.style.display = 'block';
            sa.ui.phrase.KDHelpTips.style.display = 'none';
            var sortedResults = results.sort(sa.util.sortArrayValues('Kd'));
            for (var row of sortedResults) {
                var clone = sa.ui.phrase.result.firstElementChild.cloneNode(true);

                if (row.Ph && row.Kd && row.Nq) {
                    var bar = clone.getElementsByClassName('SiteAttention_keyword_difficulty_result_competition_bar')[0];
                    var percent = Math.round(row.Kd);
                    bar.style.width = `${percent}%`;

                    clone.getElementsByClassName('SiteAttention_keyword_difficulty_result_word')[0].innerText = row.Ph;
                    clone.getElementsByClassName('SiteAttention_keyword_difficulty_result_number')[0].childNodes[1].innerText = row.Nq;
                    clone.getElementsByClassName('SiteAttention_keyword_difficulty_result_kdi')[0].childNodes[1].innerText = percent + '%';

                    sa.ui.phrase.result.appendChild(clone);
                }
            }
        },
        /*
        * Function to clear results
        **/
        clean: function () {
            var clone = sa.ui.phrase.result.firstElementChild.cloneNode(true);
            sa.ui.phrase.result.innerHTML = '';
            sa.ui.phrase.result.appendChild(clone);
        },

        /*
        * Function to clear search box
        **/
        clear_search: function () {
            sa.ui.phrase.result.style.display = 'none';
            /*sa.ui.phrase.phrase.value = '';*/
            //sa.ui.phrase.clear_result.style.display = 'none';
            sa.ui.phrase.KDHelpTips.style.display = 'block';
        }

    },


    /***************
    * EXPIRED VIEW *
    ****************/
    expired: {
        init: function (message) {
            document.getElementById('SiteAttention_expired').style.display = 'inline-flex';
            document.getElementById('SiteAttention_home').style.display = 'none';
            document.getElementById('SiteAttention_main').style.display = 'none';
            document.getElementById('SiteAttention_upgrade').style.display = 'none';
            document.getElementById("SiteAttention_notification").style.display = 'block';
            document.getElementById('SA_notification_text').innerText = sa.translate("SiteAttention license expired");
            document.getElementById('SiteAttention_onboard_outer').style.display = 'none';
            document.getElementById('SiteAttention_server_error').style.display = 'none';

            if (message) {
                document.getElementById('SiteAttention_expired_message_1').innerText = message;
            } else if (sa.globals.expiry_date && sa.globals.license_name) {
                document.getElementById('SiteAttention_expired_data').innerText = sa.globals.expiry_date;
                document.getElementById('SiteAttention_expired_license').innerText = sa.globals.license_name;
            }

        },
    },

    /***************
    * UPGRADE VIEW *
    ****************/
    upgrade: {
        init: function () {
            document.getElementById('SiteAttention_upgrade').style.display = 'inline-flex';
            document.getElementById('SiteAttention_home').style.display = 'none';
            document.getElementById('SiteAttention_main').style.display = 'none';
            document.getElementById('SiteAttention_expired').style.display = 'none';
            document.getElementById("SiteAttention_notification").style.display = 'block';
            document.getElementById('SA_notification_text').innerText = sa.translate("Time to upgrade SiteAttention subscription");
            document.getElementById('SiteAttention_onboard_outer').style.display = 'none';
            document.getElementById('SiteAttention_server_error').style.display = 'none';

            if (sa.globals.page_quota) {
                document.getElementById('SiteAttention_docs_limit').innerText = sa.globals.page_quota;
            }
        }
    },

    /***************
    * ONBOARD VIEW *
    ****************/
    onboard: {
        init: function (section) {
            //console.log('onboard' + section);
            document.getElementById('SiteAttention_upgrade').style.display = 'none';
            document.getElementById('SiteAttention_home').style.display = 'none';
            document.getElementById('SiteAttention_main').style.display = 'none';
            document.getElementById('SiteAttention_expired').style.display = 'none';
            document.getElementById("SiteAttention_notification").style.display = 'block';
            document.getElementById('SA_notification_text').innerText = sa.translate("Not yet registered in SiteAttention configuration");
            document.getElementById('SiteAttention_onboard_outer').style.display = 'block';
            document.getElementById('SiteAttention_server_error').style.display = 'none';

            $("." + section).show();
        }
    },

    /*********************
    * DISPLAY ERROR VIEW *
    **********************/
    serverError: {
        init: function () {
            document.getElementById('SiteAttention_server_error').style.display = 'inline-flex';
            document.getElementById('SiteAttention_upgrade').style.display = 'none';
            document.getElementById('SiteAttention_home').style.display = 'none';
            document.getElementById('SiteAttention_main').style.display = 'none';
            document.getElementById('SiteAttention_expired').style.display = 'none';
            document.getElementById("SiteAttention_notification").style.display = 'block';
            document.getElementById('SA_notification_text').innerText =

                sa.translate("SiteAttention: Server Error");
            document.getElementById('SiteAttention_onboard_outer').style.display = 'none';

            //document.getElementById('SiteAttention_error_report').innerText = message;
        },
        notifyError: function (message) {
            document.getElementById("SiteAttention_notification").style.display = 'block';
            document.getElementById('SA_notification_text').innerText = message;
        }
    }
};
