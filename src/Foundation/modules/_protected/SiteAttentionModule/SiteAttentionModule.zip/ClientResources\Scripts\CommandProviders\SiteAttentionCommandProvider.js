﻿define([
    "dojo/Stateful",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/xhr",
    "dojo/topic",

    "epi/dependency",
    "epi/shell/XhrWrapper",
    "epi-cms/core/ContentReference",
    "epi/shell/command/_CommandProviderMixin"
],

function (
    Stateful,
    declare,
    lang,
    xhr,
    topic,

    dependency,
    XhrWrapper,
    ContentReference,
    _CommandProviderMixin
) {
    return declare([_CommandProviderMixin], {
        _propertyEditedHandle: null,
        constructor: function () {
        },
        contentChangeTimeout: null,
        updateCommandModel: function (model) {
            this.inherited(arguments);
            this._model = model;

            if (this._propertyEditedHandle) {
                this._propertyEditedHandle.remove();
            }

            if (this._model != undefined) {
                this._propertyEditedHandle = this._model.contentModel.watch(lang.hitch(this, function (name, oldValue, newValue) {
                    this.delayedRefresh();
                }));
            }
            this.delayedRefresh();
        },
        delayedRefresh: function () {
            var self = this;
            clearTimeout(this.contentChangeTimeout);
            this.contentChangeTimeout = setTimeout(function () {
                topic.publish("siteattention/modelchanged", self._model);
            }, 1000);
        }
    });
});