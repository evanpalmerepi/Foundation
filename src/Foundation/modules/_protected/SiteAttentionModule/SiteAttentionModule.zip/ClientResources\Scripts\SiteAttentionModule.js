define([
    "dojo",
    "dojo/_base/declare",
    "dojo/_base/xhr",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/when",

    "epi/_Module",
    "epi/dependency",
    "epi/routes",
    "epi/shell/XhrWrapper",

    "siteattention/CommandProviders/SiteAttentionCommandProvider"
    //"siteattention/SiteAttentionContent"
],

    function (
        dojo,
        declare,
        xhr,
        lang,
        aspect,
        when,

        _Module,
        dependency,
        routes,
        XhrWrapper,

        SiteAttentionCommandProvider
        //SiteAttentionContent
    ) {

        // summary: Module initializer for the default module.
        return declare("siteattention.SiteAttentionModule", [_Module], {
            SACommandProvider: new SiteAttentionCommandProvider(),

            initialize: function () {
                this.inherited(arguments);
                // Register the Command Provider
                var commandregistry = dependency.resolve("epi.globalcommandregistry");
                //console.info('dependency.resolve("epi.globalcommandregistry")');
                commandregistry.registerProvider("epi.cms.publishmenu", this.SACommandProvider);
            }
        });
    });